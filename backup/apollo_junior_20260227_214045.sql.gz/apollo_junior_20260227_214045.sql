--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: behavior_type; Type: TYPE; Schema: public; Owner: apollo_junior
--

CREATE TYPE public.behavior_type AS ENUM (
    'MAZE',
    'PIXEL_ART',
    'MUSIC'
);


ALTER TYPE public.behavior_type OWNER TO apollo_junior;

--
-- Name: difficulty_type; Type: TYPE; Schema: public; Owner: apollo_junior
--

CREATE TYPE public.difficulty_type AS ENUM (
    'EASY',
    'MEDIUM',
    'HARD'
);


ALTER TYPE public.difficulty_type OWNER TO apollo_junior;

--
-- Name: target_grade; Type: TYPE; Schema: public; Owner: apollo_junior
--

CREATE TYPE public.target_grade AS ENUM (
    'SD_1_2',
    'SD_3_6',
    'SMP',
    'SMA'
);


ALTER TYPE public.target_grade OWNER TO apollo_junior;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_images; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.auth_images (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    code character varying(50) NOT NULL,
    image_url text NOT NULL,
    is_active boolean DEFAULT true
);


ALTER TABLE public.auth_images OWNER TO apollo_junior;

--
-- Name: classroom_modules; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.classroom_modules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    classroom_id uuid NOT NULL,
    module_id uuid NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE public.classroom_modules OWNER TO apollo_junior;

--
-- Name: TABLE classroom_modules; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.classroom_modules IS 'Associates modules with classrooms';


--
-- Name: COLUMN classroom_modules."order"; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.classroom_modules."order" IS 'Order of the module within the classroom';


--
-- Name: classroom_students; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.classroom_students (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    classroom_id uuid NOT NULL,
    user_id uuid NOT NULL,
    joined_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.classroom_students OWNER TO apollo_junior;

--
-- Name: TABLE classroom_students; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.classroom_students IS 'Associates students (users) with classrooms';


--
-- Name: classrooms; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.classrooms (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    alias character varying(100),
    grade_type character varying(20),
    grade_level integer,
    created_by uuid,
    tenant_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.classrooms OWNER TO apollo_junior;

--
-- Name: TABLE classrooms; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.classrooms IS 'Stores classroom entities for the junior application';


--
-- Name: COLUMN classrooms.alias; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.classrooms.alias IS 'Short alias or code for the classroom';


--
-- Name: COLUMN classrooms.grade_type; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.classrooms.grade_type IS 'Target grade type: SD, SMP, SMA';


--
-- Name: module_lessons; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.module_lessons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    module_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    step integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.module_lessons OWNER TO apollo_junior;

--
-- Name: TABLE module_lessons; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.module_lessons IS 'Stores lessons within a module';


--
-- Name: COLUMN module_lessons.step; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.module_lessons.step IS 'Order of the lesson within the module';


--
-- Name: modules; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.modules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    difficulty character varying(20),
    behavior_type character varying(20),
    grade_type character varying(20),
    grade_level integer,
    is_official boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.modules OWNER TO apollo_junior;

--
-- Name: TABLE modules; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.modules IS 'Stores learning modules for junior application';


--
-- Name: COLUMN modules.difficulty; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.modules.difficulty IS 'Module difficulty: EASY, MEDIUM, HARD';


--
-- Name: COLUMN modules.behavior_type; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.modules.behavior_type IS 'Module behavior type: MAZE, PIXEL_ART, MUSIC';


--
-- Name: COLUMN modules.grade_type; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.modules.grade_type IS 'Target grade type: SD, SMP, SMA';


--
-- Name: mst_junior_modules; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.mst_junior_modules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    difficulty public.difficulty_type,
    target_grade public.target_grade,
    behavior_type public.behavior_type,
    is_official boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.mst_junior_modules OWNER TO apollo_junior;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO apollo_junior;

--
-- Name: student_lesson_progress; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.student_lesson_progress (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    classroom_id uuid NOT NULL,
    module_id uuid NOT NULL,
    lesson_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status character varying(20) DEFAULT 'NOT_STARTED'::character varying NOT NULL,
    progress_percent integer DEFAULT 0 NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.student_lesson_progress OWNER TO apollo_junior;

--
-- Name: TABLE student_lesson_progress; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.student_lesson_progress IS 'Tracks student progress within individual lessons';


--
-- Name: COLUMN student_lesson_progress.status; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.student_lesson_progress.status IS 'Lesson status: NOT_STARTED, IN_PROGRESS, COMPLETED';


--
-- Name: COLUMN student_lesson_progress.progress_percent; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.student_lesson_progress.progress_percent IS 'Percentage of lesson completion (0-100)';


--
-- Name: student_module_progress; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.student_module_progress (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    classroom_id uuid NOT NULL,
    module_id uuid NOT NULL,
    user_id uuid NOT NULL,
    total_lessons integer NOT NULL,
    completed_lessons integer DEFAULT 0 NOT NULL,
    progress_percent integer DEFAULT 0 NOT NULL,
    is_completed boolean DEFAULT false NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.student_module_progress OWNER TO apollo_junior;

--
-- Name: TABLE student_module_progress; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.student_module_progress IS 'Tracks student progress within a module in a classroom';


--
-- Name: COLUMN student_module_progress.total_lessons; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.student_module_progress.total_lessons IS 'Total number of lessons in the module';


--
-- Name: COLUMN student_module_progress.completed_lessons; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.student_module_progress.completed_lessons IS 'Number of lessons completed by the student';


--
-- Name: COLUMN student_module_progress.progress_percent; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.student_module_progress.progress_percent IS 'Percentage of module completion (0-100)';


--
-- Name: COLUMN student_module_progress.is_completed; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.student_module_progress.is_completed IS 'Whether the student has completed all lessons';


--
-- Name: user_passwords; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.user_passwords (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    password_hash character varying(255) NOT NULL,
    password_salt character varying(64) NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    last_failed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_passwords OWNER TO apollo_junior;

--
-- Name: TABLE user_passwords; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON TABLE public.user_passwords IS 'Stores hashed passwords for user authentication';


--
-- Name: COLUMN user_passwords.password_hash; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.user_passwords.password_hash IS 'Bcrypt hash of the user password';


--
-- Name: COLUMN user_passwords.password_salt; Type: COMMENT; Schema: public; Owner: apollo_junior
--

COMMENT ON COLUMN public.user_passwords.password_salt IS 'Random salt used for password hashing';


--
-- Name: user_pins; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.user_pins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    pin_hash character varying(64) NOT NULL,
    pin_salt character varying(32) NOT NULL,
    pin_length integer DEFAULT 3 NOT NULL,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    last_failed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_pins OWNER TO apollo_junior;

--
-- Name: users; Type: TABLE; Schema: public; Owner: apollo_junior
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    username character varying(100) NOT NULL,
    display_name character varying(255),
    avatar_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO apollo_junior;

--
-- Data for Name: auth_images; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.auth_images (id, code, image_url, is_active) FROM stdin;
fb92dbe4-a71e-48f0-8335-557d19fd9208	cat-1	https://example.com/images/cat-1.png	t
958bc75e-b3d7-49ed-82b9-319afe6d71d9	dog-1	https://example.com/images/dog-1.png	t
e995cba3-ef4a-40a7-9a2f-734be947f1f4	bird-1	https://example.com/images/bird-1.png	t
54076a1f-c173-491f-9005-f6a6cb7138dd	fish-1	https://example.com/images/fish-1.png	t
ce4f6e42-6026-41b1-a805-678acd525193	rabbit-1	https://example.com/images/rabbit-1.png	t
f7eab466-b761-472e-bf75-0ef26a5944ea	elephant-1	https://example.com/images/elephant-1.png	t
945f56ae-c6c7-4cd9-a1df-06bb1914cb9f	lion-1	https://example.com/images/lion-1.png	t
66187f4b-9841-490b-a46f-c25ae3eb03ed	monkey-1	https://example.com/images/monkey-1.png	t
ee3a92d3-7a93-4806-a7a0-a23e6c0b300c	turtle-1	https://example.com/images/turtle-1.png	t
\.


--
-- Data for Name: classroom_modules; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.classroom_modules (id, classroom_id, module_id, "order") FROM stdin;
1e2e3631-b438-4da5-9160-5e64d5e41001	5109bd5c-7cec-42ec-bfde-932e68f128fd	a23b20e5-8b2f-49ef-be1a-e567816abbfd	1
7753f9e8-19b1-431a-a8d4-c928d027ee68	cf27eb90-a7d6-4b8c-8f9c-f93e12147094	a23b20e5-8b2f-49ef-be1a-e567816abbfd	1
\.


--
-- Data for Name: classroom_students; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.classroom_students (id, classroom_id, user_id, joined_at) FROM stdin;
01556ce9-bd74-4073-9ced-3758e788310f	5109bd5c-7cec-42ec-bfde-932e68f128fd	8d56a44f-2b24-45c8-9809-f5764f326c84	2026-02-19 12:36:22.538603+00
26f61011-174c-4376-bc3d-2879af2ed411	cf27eb90-a7d6-4b8c-8f9c-f93e12147094	8d56a44f-2b24-45c8-9809-f5764f326c84	2026-02-19 12:43:27.531034+00
\.


--
-- Data for Name: classrooms; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.classrooms (id, name, description, alias, grade_type, grade_level, created_by, tenant_id, created_at, updated_at) FROM stdin;
a8ecd6d0-22b1-43cc-ac71-abc424513839	dasar	kelas dasar	SD A	SD	1	0a4d61e7-deb3-410b-ae72-744a762cc797	00000000-0000-0000-0000-000000000000	2026-02-19 12:33:58.891842+00	2026-02-19 12:33:58.891842+00
cf27eb90-a7d6-4b8c-8f9c-f93e12147094	dasar	kelas dasar	SD A	SD	1	0a4d61e7-deb3-410b-ae72-744a762cc797	00000000-0000-0000-0000-000000000000	2026-02-19 12:43:27.531151+00	2026-02-19 12:43:27.531151+00
5109bd5c-7cec-42ec-bfde-932e68f128fd	Kelas Junior	kelas dasar	SD A	SD	1	0a4d61e7-deb3-410b-ae72-744a762cc797	00000000-0000-0000-0000-000000000000	2026-02-19 12:36:22.538796+00	2026-02-19 12:49:41.899889+00
\.


--
-- Data for Name: module_lessons; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.module_lessons (id, module_id, name, step, created_at, updated_at) FROM stdin;
755a5485-a38a-4b42-86fd-414fa88f8c38	a23b20e5-8b2f-49ef-be1a-e567816abbfd	Pertemuan 1	1	2026-02-25 23:18:29.142313+00	2026-02-25 23:18:29.142313+00
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.modules (id, name, description, difficulty, behavior_type, grade_type, grade_level, is_official, created_by, created_at, updated_at) FROM stdin;
1d6723fd-2358-4644-9d7f-b0fee31b35cd	Pengenalan Coding	For pemula			SD	1	t	0a4d61e7-deb3-410b-ae72-744a762cc797	2026-02-17 04:58:52.349906+00	2026-02-17 04:58:52.349906+00
18c2ca0a-e7b7-448c-b92c-d11f93dba0f2	Pengenalan Coding	For pemula			SD	1	t	0a4d61e7-deb3-410b-ae72-744a762cc797	2026-02-17 15:52:44.661636+00	2026-02-17 15:52:44.661636+00
a26a7624-90ab-4279-b141-8f9b2590dd3b	Pengenalan Coding	For pemula	EASY		SD	1	t	0a4d61e7-deb3-410b-ae72-744a762cc797	2026-02-17 15:54:07.860817+00	2026-02-17 15:54:07.860817+00
02693454-222c-4333-b386-a72b134c11ca	Pengenalan Coding	For pemula	EASY	MAZE	SD	1	t	0a4d61e7-deb3-410b-ae72-744a762cc797	2026-02-17 15:54:16.270767+00	2026-02-17 15:54:16.270767+00
47d70174-0542-458c-be28-24054812fb3f	Pengenalan Coding	For pemula	EASY	MAZE	SD	1	t	0a4d61e7-deb3-410b-ae72-744a762cc797	2026-02-17 15:55:19.911189+00	2026-02-17 15:55:19.911189+00
a23b20e5-8b2f-49ef-be1a-e567816abbfd	Pengenalan Coding	For pemula	EASY	MAZE	SD	1	t	0a4d61e7-deb3-410b-ae72-744a762cc797	2026-02-17 15:55:22.519858+00	2026-02-17 15:55:22.519858+00
\.


--
-- Data for Name: mst_junior_modules; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.mst_junior_modules (id, title, description, difficulty, target_grade, behavior_type, is_official, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.schema_migrations (version, dirty) FROM stdin;
8	f
\.


--
-- Data for Name: student_lesson_progress; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.student_lesson_progress (id, classroom_id, module_id, lesson_id, user_id, status, progress_percent, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_module_progress; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.student_module_progress (id, classroom_id, module_id, user_id, total_lessons, completed_lessons, progress_percent, is_completed, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_passwords; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.user_passwords (id, user_id, password_hash, password_salt, failed_attempts, locked_until, last_failed_at, created_at, updated_at) FROM stdin;
9133ec2e-0f36-484d-aa40-ffe380b78c6f	9546cd86-b291-4c31-a0f4-699aeaa43643	$2a$10$xVudkB3RZe9EHcxu5J6J/emNz05f46bRr9tYNCb4RCoydSvCBzctK	b7dd4fcff724dbd9a9406f0f20d484608d4c436d3e45ce40355565e2864592b3	0	\N	\N	2026-02-21 01:32:07.475323+00	2026-02-21 01:34:06.11871+00
521c3485-3bbf-4021-9d63-77937b42142b	5ee49b77-ab78-432e-8920-120b9f4b3704	$2a$10$CbxT.hUnw326qUDhbS9Rn.rMWI9MBtkOP8qcH6Sc.l7arymSDMLma	67fee39b4a90c2976bee73794d6504f473a9e085ae80c79a7c3dce566442d7ed	0	\N	\N	2026-02-21 03:00:26.100753+00	2026-02-21 03:00:26.100753+00
\.


--
-- Data for Name: user_pins; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.user_pins (id, user_id, pin_hash, pin_salt, pin_length, failed_attempts, locked_until, last_failed_at, created_at, updated_at) FROM stdin;
69d01960-da41-4ac8-a1da-3449b11543c0	08b09044-c1f6-4ee6-9436-4da496004d65	c54bc89ccd352a44c93d71f8f9d2b26e4f71ed848725684fd1c01ede80fb3b05	3c026e263a601ccb7a09234a778368e3	3	0	\N	\N	2026-02-14 09:05:45.906899+00	2026-02-14 09:05:45.906899+00
dd98e033-8576-40c8-9635-cc6b7200a609	fccfccdb-ff78-4572-a404-54ef5a872245	7eb55b0964161c5420952aaeb1d9e9c5f6e57631520c085de99168335e50f73e	20af06e3c5f7898d8e8a4b08e1417d2b	3	0	\N	\N	2026-02-14 10:17:26.871691+00	2026-02-14 10:17:26.871691+00
dda088e5-e6a4-4e8c-a74d-a9176c224336	9894f94d-6204-4bcd-a0d1-8e9cd2abc68c	15d0748210c97bf60bcc417ce8d91eacf52038c89cf3c21cd7400089080d8a4e	9998863a895b5afccfffa9d384383709	3	0	\N	\N	2026-02-14 10:18:51.099765+00	2026-02-14 10:18:51.099765+00
4b477ce3-defa-4549-bf17-033857b84b88	49e44bdc-99ea-416e-80d8-8990e4fc45a6	594e1be97b76db8135e3273748e2cd8796172f9f0d38602e70b69576028343f1	766e5eabbf28006a38e3478e74632221	3	0	\N	\N	2026-02-21 03:10:16.848191+00	2026-02-21 03:10:16.848191+00
84692015-b90a-4d0e-82b7-ea9c27fef55c	8d56a44f-2b24-45c8-9809-f5764f326c84	5a13a0800d3c9a38e288acc8cfdc843dbbbdbfe957bf8f1f6c3284f3e1b4e4fc	e80fc087b4e8d8290a7f23664900224a	3	0	\N	\N	2026-02-15 00:20:46.343735+00	2026-02-25 23:58:20.49149+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: apollo_junior
--

COPY public.users (id, tenant_id, username, display_name, avatar_url, is_active, created_at, updated_at, deleted_at) FROM stdin;
08b09044-c1f6-4ee6-9436-4da496004d65	00000000-0000-0000-0000-000000000000	001	John	https://example.com/avatars/my.jpeg	t	2026-02-14 09:05:45.906899+00	2026-02-14 09:05:45.906899+00	\N
fccfccdb-ff78-4572-a404-54ef5a872245	00000000-0000-0000-0000-000000000000	00101	John	https://example.com/avatars/my.jpeg	t	2026-02-14 10:17:26.871691+00	2026-02-14 10:17:26.871691+00	\N
9894f94d-6204-4bcd-a0d1-8e9cd2abc68c	00000000-0000-0000-0000-000000000000	001012	John	https://example.com/avatars/my.jpeg	t	2026-02-14 10:18:51.099765+00	2026-02-14 10:18:51.099765+00	\N
8d56a44f-2b24-45c8-9809-f5764f326c84	00000000-0000-0000-0000-000000000000	0010122	John	https://example.com/avatars/my.jpeg	t	2026-02-15 00:20:46.343735+00	2026-02-15 00:20:46.343735+00	\N
9546cd86-b291-4c31-a0f4-699aeaa43643	00000000-0000-0000-0000-000000000000	1933	John		t	2026-02-21 01:32:07.475323+00	2026-02-21 01:32:07.475323+00	\N
5ee49b77-ab78-432e-8920-120b9f4b3704	00000000-0000-0000-0000-000000000000	1933011	Zulkarnen		t	2026-02-21 03:00:26.100753+00	2026-02-21 03:00:26.100753+00	\N
49e44bdc-99ea-416e-80d8-8990e4fc45a6	00000000-0000-0000-0000-000000000000	1933012	Nashifa		t	2026-02-21 03:10:16.848191+00	2026-02-21 03:10:16.848191+00	\N
\.


--
-- Name: auth_images auth_images_code_key; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.auth_images
    ADD CONSTRAINT auth_images_code_key UNIQUE (code);


--
-- Name: auth_images auth_images_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.auth_images
    ADD CONSTRAINT auth_images_pkey PRIMARY KEY (id);


--
-- Name: classroom_modules classroom_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_modules
    ADD CONSTRAINT classroom_modules_pkey PRIMARY KEY (id);


--
-- Name: classroom_students classroom_students_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_students
    ADD CONSTRAINT classroom_students_pkey PRIMARY KEY (id);


--
-- Name: classrooms classrooms_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classrooms
    ADD CONSTRAINT classrooms_pkey PRIMARY KEY (id);


--
-- Name: module_lessons module_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.module_lessons
    ADD CONSTRAINT module_lessons_pkey PRIMARY KEY (id);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- Name: mst_junior_modules mst_junior_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.mst_junior_modules
    ADD CONSTRAINT mst_junior_modules_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: student_lesson_progress student_lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_lesson_progress
    ADD CONSTRAINT student_lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: student_module_progress student_module_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_module_progress
    ADD CONSTRAINT student_module_progress_pkey PRIMARY KEY (id);


--
-- Name: classroom_modules uq_classroom_modules_classroom_module; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_modules
    ADD CONSTRAINT uq_classroom_modules_classroom_module UNIQUE (classroom_id, module_id);


--
-- Name: classroom_students uq_classroom_students_classroom_user; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_students
    ADD CONSTRAINT uq_classroom_students_classroom_user UNIQUE (classroom_id, user_id);


--
-- Name: module_lessons uq_module_lessons_module_step; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.module_lessons
    ADD CONSTRAINT uq_module_lessons_module_step UNIQUE (module_id, step);


--
-- Name: student_lesson_progress uq_student_lesson_progress_classroom_lesson_user; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_lesson_progress
    ADD CONSTRAINT uq_student_lesson_progress_classroom_lesson_user UNIQUE (classroom_id, lesson_id, user_id);


--
-- Name: student_module_progress uq_student_module_progress_classroom_module_user; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_module_progress
    ADD CONSTRAINT uq_student_module_progress_classroom_module_user UNIQUE (classroom_id, module_id, user_id);


--
-- Name: user_passwords uq_user_passwords_user; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.user_passwords
    ADD CONSTRAINT uq_user_passwords_user UNIQUE (user_id);


--
-- Name: user_pins uq_user_pins_user; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.user_pins
    ADD CONSTRAINT uq_user_pins_user UNIQUE (user_id);


--
-- Name: users uq_users_tenant_username; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_tenant_username UNIQUE (tenant_id, username);


--
-- Name: user_passwords user_passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.user_passwords
    ADD CONSTRAINT user_passwords_pkey PRIMARY KEY (id);


--
-- Name: user_pins user_pins_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.user_pins
    ADD CONSTRAINT user_pins_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_classroom_modules_classroom_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_classroom_modules_classroom_id ON public.classroom_modules USING btree (classroom_id);


--
-- Name: idx_classroom_students_classroom_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_classroom_students_classroom_id ON public.classroom_students USING btree (classroom_id);


--
-- Name: idx_classrooms_created_by; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_classrooms_created_by ON public.classrooms USING btree (created_by);


--
-- Name: idx_classrooms_tenant_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_classrooms_tenant_id ON public.classrooms USING btree (tenant_id);


--
-- Name: idx_module_lessons_module_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_module_lessons_module_id ON public.module_lessons USING btree (module_id);


--
-- Name: idx_modules_behavior_type; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_modules_behavior_type ON public.modules USING btree (behavior_type);


--
-- Name: idx_modules_created_by; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_modules_created_by ON public.modules USING btree (created_by);


--
-- Name: idx_modules_difficulty; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_modules_difficulty ON public.modules USING btree (difficulty);


--
-- Name: idx_modules_grade_type; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_modules_grade_type ON public.modules USING btree (grade_type);


--
-- Name: idx_modules_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE UNIQUE INDEX idx_modules_id ON public.modules USING btree (id);


--
-- Name: idx_student_lesson_progress_classroom_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_student_lesson_progress_classroom_id ON public.student_lesson_progress USING btree (classroom_id);


--
-- Name: idx_student_lesson_progress_module_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_student_lesson_progress_module_id ON public.student_lesson_progress USING btree (module_id);


--
-- Name: idx_student_lesson_progress_user_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_student_lesson_progress_user_id ON public.student_lesson_progress USING btree (user_id);


--
-- Name: idx_student_module_progress_classroom_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_student_module_progress_classroom_id ON public.student_module_progress USING btree (classroom_id);


--
-- Name: idx_student_module_progress_module_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_student_module_progress_module_id ON public.student_module_progress USING btree (module_id);


--
-- Name: idx_student_module_progress_user_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_student_module_progress_user_id ON public.student_module_progress USING btree (user_id);


--
-- Name: idx_user_passwords_locked_until; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_user_passwords_locked_until ON public.user_passwords USING btree (locked_until) WHERE (locked_until IS NOT NULL);


--
-- Name: idx_user_passwords_user_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_user_passwords_user_id ON public.user_passwords USING btree (user_id);


--
-- Name: idx_user_pins_locked_until; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_user_pins_locked_until ON public.user_pins USING btree (locked_until) WHERE (locked_until IS NOT NULL);


--
-- Name: idx_user_pins_user_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_user_pins_user_id ON public.user_pins USING btree (user_id);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree (deleted_at) WHERE (deleted_at IS NULL);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: apollo_junior
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: classroom_modules fk_classroom_modules_classroom_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_modules
    ADD CONSTRAINT fk_classroom_modules_classroom_id FOREIGN KEY (classroom_id) REFERENCES public.classrooms(id) ON DELETE CASCADE;


--
-- Name: classroom_modules fk_classroom_modules_module_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_modules
    ADD CONSTRAINT fk_classroom_modules_module_id FOREIGN KEY (module_id) REFERENCES public.modules(id) ON DELETE CASCADE;


--
-- Name: classroom_students fk_classroom_students_classroom_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_students
    ADD CONSTRAINT fk_classroom_students_classroom_id FOREIGN KEY (classroom_id) REFERENCES public.classrooms(id) ON DELETE CASCADE;


--
-- Name: classroom_students fk_classroom_students_user_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.classroom_students
    ADD CONSTRAINT fk_classroom_students_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: module_lessons fk_module_lessons_module_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.module_lessons
    ADD CONSTRAINT fk_module_lessons_module_id FOREIGN KEY (module_id) REFERENCES public.modules(id) ON DELETE CASCADE;


--
-- Name: student_lesson_progress fk_student_lesson_progress_classroom_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_lesson_progress
    ADD CONSTRAINT fk_student_lesson_progress_classroom_id FOREIGN KEY (classroom_id) REFERENCES public.classrooms(id) ON DELETE CASCADE;


--
-- Name: student_lesson_progress fk_student_lesson_progress_lesson_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_lesson_progress
    ADD CONSTRAINT fk_student_lesson_progress_lesson_id FOREIGN KEY (lesson_id) REFERENCES public.module_lessons(id) ON DELETE CASCADE;


--
-- Name: student_lesson_progress fk_student_lesson_progress_module_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_lesson_progress
    ADD CONSTRAINT fk_student_lesson_progress_module_id FOREIGN KEY (module_id) REFERENCES public.modules(id) ON DELETE CASCADE;


--
-- Name: student_lesson_progress fk_student_lesson_progress_user_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_lesson_progress
    ADD CONSTRAINT fk_student_lesson_progress_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: student_module_progress fk_student_module_progress_classroom_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_module_progress
    ADD CONSTRAINT fk_student_module_progress_classroom_id FOREIGN KEY (classroom_id) REFERENCES public.classrooms(id) ON DELETE CASCADE;


--
-- Name: student_module_progress fk_student_module_progress_module_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_module_progress
    ADD CONSTRAINT fk_student_module_progress_module_id FOREIGN KEY (module_id) REFERENCES public.modules(id) ON DELETE CASCADE;


--
-- Name: student_module_progress fk_student_module_progress_user_id; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.student_module_progress
    ADD CONSTRAINT fk_student_module_progress_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_passwords user_passwords_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.user_passwords
    ADD CONSTRAINT user_passwords_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_pins user_pins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: apollo_junior
--

ALTER TABLE ONLY public.user_pins
    ADD CONSTRAINT user_pins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

